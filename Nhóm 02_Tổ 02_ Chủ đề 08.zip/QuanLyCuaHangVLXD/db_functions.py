import mysql.connector
from mysql.connector import Error


def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Minh@120705",
        database="qlch_vlxd",
        port=3307  
    )


# ============================
#    LOAD TABLE
# ============================
def load_table(table):
    try:
        conn = connect_db()
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {table}")
        rows = cur.fetchall()
        conn.close()
        return rows
    except Error as e:
        print("DB ERROR (load):", e)
        return []


# ============================
#     ADD RECORD
# ============================
def add_record(table, fields, values):
    try:
        conn = connect_db()
        cur = conn.cursor()

        placeholders = ",".join(["%s"] * len(values))
        sql = f"INSERT INTO {table} ({','.join(fields)}) VALUES ({placeholders})"

        cur.execute(sql, values)
        conn.commit()
        conn.close()

    except Error as e:
        print("DB ERROR (add):", e)
        raise


# ============================
#    DELETE RECORD
# ============================
def delete_record(table, key_field, key_value):
    try:
        conn = connect_db()
        cur = conn.cursor()

        sql = f"DELETE FROM {table} WHERE {key_field}=%s"
        cur.execute(sql, (key_value,))

        conn.commit()
        conn.close()

    except Error as e:
        print("DB ERROR (delete):", e)
        raise


# ============================
#   UPDATE RECORD
# ============================
def update_record(table, key_field, key_value, fields, values):
    try:
        conn = connect_db()
        cur = conn.cursor()

        set_clause = ",".join(f"{f}=%s" for f in fields)
        sql = f"UPDATE {table} SET {set_clause} WHERE {key_field}=%s"

        params = values + [key_value]

        cur.execute(sql, params)
        conn.commit()
        conn.close()

    except Error as e:
        print("DB ERROR (update):", e)
        raise


# ============================
#     SEARCH RECORD
# ============================
def search_record(table, field, keyword):
    try:
        conn = connect_db()
        cur = conn.cursor()

        sql = f"SELECT * FROM {table} WHERE {field} LIKE %s"
        cur.execute(sql, (f"%{keyword}%",))

        rows = cur.fetchall()
        conn.close()
        return rows

    except Error as e:
        print("DB ERROR (search):", e)
        return []
